All info in Description.docx about structure and links.
