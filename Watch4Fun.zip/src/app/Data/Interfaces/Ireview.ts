export interface Ireview {
    reviewId: number;
    showId: number;
    userid:number;
    rating: number;
    detail: string;
}