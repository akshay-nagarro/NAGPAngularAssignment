export interface valueViewValuepair {
    value:string;
    viewvalue:string
}