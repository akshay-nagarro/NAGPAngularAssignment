import { valueViewValuepair } from "../Interfaces/valueViewValuePair";

export class Languages {
    public static languageCategories: valueViewValuepair[] = [
        {value:'Hindi', viewvalue:'Hindi'},
        {value:'English', viewvalue:'English'},
        {value:'Tamil', viewvalue:'Tamil'},
        {value:'Telugu', viewvalue:'Telugu'},
    ]
    
}