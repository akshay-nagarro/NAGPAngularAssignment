import{valueViewValuepair} from "src/app/Data/Interfaces/valueViewValuePair";

export class TypeOfShow {
   public static typeofshow: valueViewValuepair[] = [
        {value:'Movie', viewvalue:'Movie'},
        {value:'TV Show', viewvalue:'TV Show'},
        ];
}


