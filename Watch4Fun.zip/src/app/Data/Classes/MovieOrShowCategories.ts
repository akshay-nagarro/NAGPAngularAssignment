import{valueViewValuepair} from "src/app/Data/Interfaces/valueViewValuePair";

export class MovieOrShowCategories {
   public static genreCategories: valueViewValuepair[] = [
        {value:'Action', viewvalue:'Action'},
        {value:'Horror', viewvalue:'Horror'},
        {value:'Adventure', viewvalue:'Adventure'},
        {value:'Drama', viewvalue:'Drama'},
        {value:'Crime', viewvalue:'Crime'},
        {value:'Animation', viewvalue:'Animation'},
        {value:'Sci Fi', viewvalue:'Sci Fi'},
        {value:'Fantasy', viewvalue:'Fantasy'},
        {value:'Kids', viewvalue:'Kids'},
        {value:'Thriller', viewvalue:'Thriller'},
        {value:'Misc', viewvalue:'Misc'},
        ];
}


