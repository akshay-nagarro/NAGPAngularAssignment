import{valueViewValuepair} from "src/app/Data/Interfaces/valueViewValuePair";

export class TrueFalse {
   public static trueorfalse: valueViewValuepair[] = [
        {value:'True', viewvalue:'True'},
        {value:'False', viewvalue:'False'},
        ];
}


